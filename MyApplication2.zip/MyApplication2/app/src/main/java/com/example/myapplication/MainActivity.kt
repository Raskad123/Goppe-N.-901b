package com.example.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
//import android.widget.TextView
import android.widget.*
import androidx.core.widget.doAfterTextChanged

class MainActivity : AppCompatActivity() {


    val numArr = arrayOf(2, 8, 16)
    var input = 0
    var sys = numArr[0]


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // fun refresh() {}


        val inputNum = findViewById<EditText>(R.id.textInputEditText)
        inputNum.doAfterTextChanged {
            input = it.toString().toIntOrNull() ?: 0
            refresh()
        }

        val spinner = findViewById<Spinner>(R.id.spinner)

        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, numArr)
        spinner.adapter = adapter
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {
                //Log.d(getString(R.string.app_name), "${numArr[p2]}")
                sys = numArr[p2]
                refresh()
            }

            override fun onNothingSelected(p0: AdapterView<*>?) {
                TODO("Not yet implemented")
            }

        }




    }

    fun refresh() {
        val res = input.toString(sys)
        val result = findViewById<TextView>(R.id.textView)
        result.text = res.toString()
    }
}